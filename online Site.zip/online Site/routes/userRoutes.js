const express = require('express');
const router = express.Router();
const UserController = require('../controllers/userController.js');
const checkUserAuth = require("../middlewares/auth-middlewares.js");
const auth = require("../middlewares/adminAuth.js");


// Route Level Middleware - To Protect Route
router.use('/changepassword',checkUserAuth)
router.use('/loggedUser',checkUserAuth)



router.post('/register',UserController.userRegistration)
router.post('/login',UserController.userLogin)
router.post('/send-Reset-password-email',UserController.sendUserPasswordResetEmail)
router.post('/reset-password/:id/:token',UserController.userPasswordReset)
router.post('/contact', UserController.contactinfo)

//Protected Routes
router.post('/changepassword',UserController.changeUserPassword)
router.get('/loggedUser',UserController.loggedUser)

//public Routes
router.get('/', UserController.home1)
router.get('/register',UserController.register)

router.get('/login',UserController.login)

router.get('/login',(req,res)=>{
    if(req.session.authorized){
        res.render('/home',{email:req.session.user.email});
    }else{
        res.render('login');
    }
})


router.get('/changepassword',UserController.changepassword)
router.get('/home',auth.isLogout,UserController.home)
router.get('/about',UserController.about)
router.get('/contact',UserController.contact)
router.get('/profile', UserController.profile)
router.get('/services',UserController.services)
router.get('/logout',auth.isLogin,UserController.logout)
router.get('/myprofile',UserController.myprofile)

module.exports=router