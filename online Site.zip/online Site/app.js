const dotenv = require("dotenv");
const express = require('express');
const cors = require('cors');
const connectDB = require('./config/connectdb.js');
const userRoutes = require('./routes/userRoutes.js');
const ejs = require('ejs');
const path = require('path');
const bodyParser =require('body-parser');
const cookieParser = require("cookie-parser");
const session = require('express-session');
const flash = require('connect-flash');


const app = express()
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())
app.use(cookieParser())
dotenv.config();
app.use(express.static(path.join(__dirname, 'public')));
app.use('/css',express.static(path.join(__dirname, 'public/css')));


app.use(
    session({
      secret: process.env.JWT_SECRET_KEY,
      saveUninitialized: false,
      resave: false,
      cookie: {
        maxAge: 1000*60*10,
      },
    })
  );

  app.use(flash());


const views = path.join(__dirname, 'views')
app.set("views", views)
app.set('view engine','ejs')


const port = process.env.PORT
const DATABASE_URL = process.env.DATABASE_URL


//CORS Policy
app.use(cors())

//Database Connection
connectDB(DATABASE_URL)

//JSON
app.use(express.json())

//Load Routes
app.use("/", userRoutes)


app.listen(port, () =>{
    console.log(`Server Listening at http://localhost:${port}`)
})