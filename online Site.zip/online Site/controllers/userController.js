const UserModel = require('../models/user.js');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const transporter = require('../config/emailConfig.js');


class UserController {
    static userRegistration = async (req, res) => {
        const { name, lname, email, phone, password, password_confirmation } = req.body
        const user = await UserModel.findOne({email: req.body.email})
        const user1 = await UserModel.findOne({phone: req.body.phone})
        if (user || user1) {
            res.send({ "Status": "failed", "message": "Email and phone No alrady exists" })
        } else {
            if (name && lname && email && password && password_confirmation) {
                if (password === password_confirmation) {
                    try {
                        const salt = await bcrypt.genSalt(10)
                        const hashPassword = await bcrypt.hash(password, salt)

                        const doc = new UserModel({
                            name: name,
                            lname: lname,
                            email: email,
                            phone: phone,
                            password: hashPassword,
                            password_confirmation: hashPassword

                        })
                        const vt = await doc.save()
                        const saved_user = await UserModel.findOne({ email:req.body.email})
                        // Generate JWT Token
                        const token = jwt.sign({ userID: saved_user._id }, process.env.JWT_SECRET_KEY, { expiresIn: '5m' })

                        res.render("login")

                    } catch (error) {
                        res.send({ "Status": "failed", "message": "Unable to Register" })
                    }

                } else {
                    res.send({ "Status": "failed", "message": "password and password confirmation doesn't Match " })
                }
            } else {
                res.send({ "Status": "failed", "message": "All Fields Are Required" })
            }
        }

    }

    static userLogin = async (req, res) => {
        try {
            const { email, password } = req.body
            if (email && password) {
                const user = await UserModel.findOne({email:req.body.email })
                if (user != null) {
                    const isMatch = await bcrypt.compare(password, user.password)
                    if ((user.email === email) && isMatch) {
                        //Generate JWT Token
                        const token = jwt.sign({ userID: user._id }, process.env.JWT_SECRET_KEY, { expiresIn: '3m' })
                        
                        if(user){
                            req.session.user = user;
                            req.session.authorized = true;
                            res.render("home",{email});
                        }else{
                            res.render("login");
                        }

                      // res.render("home")

                    } else {
                        res.send({ "Status": "failed", "message": "Email and password is not valid" })
                    }
                } else {
                    res.send({ "Status": "failed", "message": "You are not a Registered User" })
                }
            } else {
                res.send({ "Status": "failed", "message": "All Fields Are Required" })
            }
        } catch (error) {
            console.log(error)
            res.send({ "Status": "failed", "message": "Unable to Login" })
        }
    }

    static changeUserPassword = async (req, res) => {
        const { password, password_confirmation } = req.body
        if (password && password_confirmation) {
            if (password !== password_confirmation) {
                res.send({ "Status": "failed", "message": "password and New password confirmation doesn't Match " })
            } else {
                const salt = await bcrypt.genSalt(10)
                const newHashPassword = await bcrypt.hash(password, salt)
                await UserModel.findByIdAndUpdate(req.user._id, { $set: { password: newHashPassword } })
                res.send({ "status": "success", "message": "Password change succesfully" })
            }
        } else {
            res.send({ "Status": "failed", "message": "All Fields Are Required" })
        }
    }

    static loggedUser = async (req, res) => {
        res.send({ "user": req.user })
    }

    static sendUserPasswordResetEmail = async (req, res) => {
        const { email } = req.body
        if (email) {
            const user = await UserModel.findOne({ email: email })

            if (user) {
                const secret = user._id + process.env.JWT_SECRET_KEY
                const token = jwt.sign({ userID: user._id }, secret, { expiresIn: '3m' })

                const link = `http://127.0.0.1:3000/api/user/reset/${user._id}/${token}`

                console.log(link)
                //Send Email
                let info = await transporter.sendMail({
                    from: process.env.EMAIL_FROM,
                    to: user.email,
                    subject: "Geekshop - password Reset Link",
                    html: `<a href = ${link} >Click Here </a> to Rest Your Password`
                })

                res.send({ "Status": "success", "message": "Password Reset Email Sent.. Please Check your Email", "info": info })
            } else {
                res.send({ "Status": "failed", "message": "Email doesn't exists" })
            }
        } else {
            res.send({ "Status": "failed", "message": "Email Field is Required" })
        }
    }

    static userPasswordReset = async (req, res) => {
        const { password, password_confirmation } = req.body
        const { id, token } = req.params
        const user = await UserModel.findById(id)
        const new_secret = user._id + process.env.JWT_SECRET_KEY
        try {
            jwt.verify(token, new_secret)
            if (password && password_confirmation) {
                if (password !== password_confirmation) {
                    res.send({ "Status": "failed", "message": "password and New password confirmation doesn't Match " })
                } else {
                    const salt = await bcrypt.genSalt(10)
                    const newHashPassword = await bcrypt.hash(password, salt)
                    await UserModel.findByIdAndUpdate(user._id, { $set: { password: newHashPassword } })
                    res.send({ "status": "success", "message": "Password change succesfully" })
                }

            } else {
                res.send({ "Status": "failed", "message": "All Field are Required" })
            }

        } catch (error) {
            console.log(error)
            res.send({ "status": "failed", "message": "Invalid Token " })
        }
    }



    static contactinfo = async (req, res) => {
        const uname = req.body.Firstname;
        const ulastname = req.body.Lastname;
        const umail = req.body.Email;
        const umnumber = req.body.Mobile;
        const mess = req.body.Message;
        
        // var transpoter = transporter.createTransporter({
            //     service:'gmail',
            //     auth:{
                //         user:process.env.EMAIL_USER,
                //         pass:process.env.EMAIL_PASS
                //     },
                //     port:process.env.EMAIL_PORT,
                //     host:process.env.EMAIL_HOST
                // })
                var mailOptions ={
                    form:process.env.EMAIL_USER,
                    to:req.body.umail,
                    cc:process.env.EMAIL_USER,
                    subject:'Thanks for giving feedback--> '+ uname,
                    text:`Thanks for your message you have sent to us 
                    Name: ${uname} 
                    Last Name: ${ulastname} 
                    Email-Id: ${umail}
                    Mobile No:${umnumber} 
                    Message: ${mess}`
                };
                transporter.sendMail(mailOptions,function(err,info){
                    if(err){
                        console.log('error',err);
                    }
                    else{
                        console.log("email sent successfully" + contactinfo.response);
                    }
                    res.redirect('home');
        })
    
    
    }

        
    static home1 = async (req, res) => {
        res.render('home1')
    }

    static register = async (req, res) => {
        res.render('register')
    }

    static login = async (req, res) => {
        res.render('login')
    }

    static changepassword = async (req, res) => {
        if(req?.session?.email){

            res.render('changepassword')
        }else{
            res.redirect('/login')
        }
    }

    static home = async (req, res) => {
        if(req?.session?.authorized){
        res.render('home')
        }else{
        res.redirect('/login')
        }   
    }

    static about = async (req, res) => {
        if(req?.session?.authorized){
            res.render('about')
        }else{
            res.redirect('/login')
        }    
    }

    static contact = async (req, res) => {
        if(req?.session?.authorized){
        res.render('contact')
        }else{
        res.redirect('/login')
        }  
    }

    static profile = async (req, res) => {
        if(req?.session?.authorized){
        res.render('profile')

        }else
        {
        res.redirect('/login')
    }
}

    static services = async (req, res) => {
        if(req?.session?.authorized){
        res.render('services')
        }else{
    res.redirect('/login')
    }
}

static logout = async (req, res) => {
    try {
        
        req.session.destroy();
        localStorage.clear()
        res.redirect('/login');
        
    } catch (error) {
            console.log(error)
            res.send({ "status": "failed", "message": "logout " })
    }

}

static myprofile = async (req, res) => {
    try {
        console.log(req.session)
        if(req?.session?.authorized){
            const userData = await UserModel.findById({_id:req.session.user._id});
        res.render('myprofile',{user:userData})
        console.log(userData);
        }else{
        res.redirect('/login')
        }  
    } catch (error) {
        console.log(error)
        res.send(error)
    }
    
    
}

}
module.exports=UserController